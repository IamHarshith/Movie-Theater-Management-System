﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbsproject
{
    public partial class link : Form
    {
        public link()
        {
            InitializeComponent();
        }
        public static class formstate
        {
            public static SignIn form;
        }

        private void button1_Click(object sender, EventArgs e)
        {
            //this.Hide();
            MessageBox.Show("LINK HAS BEEN SENT SUCCESSFULLY");

          


        }
    }
}

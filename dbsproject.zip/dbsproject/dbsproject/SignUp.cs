﻿
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using System.Text.RegularExpressions;

namespace dbsproject
{
    public partial class SignUp : Form
    {
        int i = 0;
        int j = 0;
        MySql.Data.MySqlClient.MySqlConnection conn;
        string myConnectionString;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        DataColumn dc;
        MySql.Data.MySqlClient.MySqlCommand comm;
        MySql.Data.MySqlClient.MySqlDataAdapter adap;
       
        

        public SignUp()
        {
            myConnectionString = "server = localhost;user id = root; password =9844897278jsn;database = users;";


            conn = new MySql.Data.MySqlClient.MySqlConnection(myConnectionString);
            conn.Open();
            InitializeComponent();

        }

        private void Form5_Load(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
           

        }
        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            comm = new MySql.Data.MySqlClient.MySqlCommand();
            comm.Connection = conn;
            comm.CommandText = "insert into login values('" + name.Text + "','" + contact.Text + "','" + password.Text.ToString() + "','" + username.Text + "')";
            comm.CommandType = CommandType.Text;
            try
            {
                comm.ExecuteNonQuery();
            }
            catch (Exception ex)
            {
                MessageBox.Show(ex.ToString());
            }
            conn.Close();
            this.Hide();
        }

        private void button1_Click_1(object sender, EventArgs e)
        {
            int l = contact.Text.Length;
            String name1 = name.Text;
            int nl = name1.Length;

            /*  if (!System.Text.RegularExpressions.Regex.IsMatch(username.Text, "^[a-zA-Z]"))
              {
                  MessageBox.Show("Enter Valid Name");
                  // username.Text.Remove(username.Text.Length - 1);
              }*/
              
            if (name.Text == ("") || username.Text == ("") || password.Text == ("") || contact.Text == (""))
            {
                MessageBox.Show("All fields are mandatory");
            }

            else if (password.Text.Length < 8)
            {
                MessageBox.Show("password must be atleast 8 characters");
            }
            else if (contact.Text.Length < 10)
            {
                MessageBox.Show("enter valid mobile number");

            }
            else
            {
                comm = new MySql.Data.MySqlClient.MySqlCommand();
                comm.Connection = conn;
                comm.CommandText = "insert into login values('" + name.Text + "','" + contact.Text + "','" + password.Text.ToString() + "','" + username.Text + "')";
                comm.CommandType = CommandType.Text;
                try
                {
                    comm.ExecuteNonQuery();
                }
                catch (Exception ex)
                {
                    // MessageBox.Show(ex.ToString());
                    MessageBox.Show("Username Already exists");
                    username.Text = "";
                }
                conn.Close();
                this.Hide();

            }
        }

        private void username_TextChanged(object sender, EventArgs e)
        {

        }

        private void mobileno_TextChanged(object sender, EventArgs e)
        {

        }

        private void contact_KeyDown(object sender, KeyEventArgs e)
        {
            if (e.KeyCode < Keys.D0 || e.KeyCode > Keys.D9)
            {
                e.Handled = true;
            }
        }

        private void contact_KeyPress(object sender, KeyPressEventArgs e)
        {

            if (!char.IsControl(e.KeyChar) && !char.IsDigit(e.KeyChar) && (e.KeyChar != '.'))
            {
                e.Handled = true;
            }
            if ((e.KeyChar == '.') && ((sender as TextBox).Text.IndexOf('.') > -1))
            {
                e.Handled = true;

            }

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void checkBox1_CheckedChanged(object sender, EventArgs e)
        {
            if (checkBox1.Checked)
            {
                password.Hide();
                textBox1.Text = password.Text;
                textBox1.Show();
            }
            else
            {
                textBox1.Hide();
                password.Show();
            }
        }

        private void name_KeyPress(object sender, KeyPressEventArgs e)
        {
            if(!char.IsLetter(e.KeyChar)&&!char.IsControl(e.KeyChar)&&!char.IsWhiteSpace(e.KeyChar))
            {
                e.Handled = true;
            }
        }
    }   
}

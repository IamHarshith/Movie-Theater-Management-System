﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbsproject
{
    public partial class SignIn : Form
    { int i = 0;
        SignIn ss;
        int j = 0;
        MySql.Data.MySqlClient.MySqlConnection conn;
        string myConnectionString;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        DataColumn dc;
        MySql.Data.MySqlClient.MySqlCommand comm;
        MySql.Data.MySqlClient.MySqlDataAdapter adap;
public SignIn()
        {

            InitializeComponent();
        }
        public void connect1()
        {
            myConnectionString = "server = localhost; user id = root; password =  9844897278jsn; database = users;";


            conn = new MySql.Data.MySqlClient.MySqlConnection(myConnectionString);
            conn.Open();

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == ("") && textBox2.Text == (""))
            {
                MessageBox.Show("Enter Username and Password");
            }
            else if(textBox1.Text == (""))
            {
                MessageBox.Show("Enter Username");
            }
            else if (textBox2.Text == (""))
            {
                MessageBox.Show("Enter Password");
            }
           else {
                connect1();
                comm = new MySql.Data.MySqlClient.MySqlCommand();
                comm.CommandText = "select * from login";
                comm.CommandType = CommandType.Text;
                ds = new DataSet();
                adap = new MySql.Data.MySqlClient.MySqlDataAdapter(comm.CommandText, conn);
                adap.Fill(ds, "login");
                dt = ds.Tables["login"];

                // MessageBox.Show(dt.Rows.Count.ToString());
                int t = dt.Rows.Count;
                dr = dt.Rows[i];
                dc = dt.Columns[j];
                j++;
                Boolean found = false;
                //int id;
                // searching databse table for username and password
                while (i < t)
                {
                    dr = dt.Rows[i];
                    if (dr["mobno"].ToString().Equals(textBox1.Text))
                        if (dr["password"].ToString().Equals(textBox2.Text))
                        {
                            found = true;
                            Book f2 = new Book();
                            this.Hide();
                            f2.Show();
                        }
                    if (found == true)
                        break;
                    else
                        i++;
                }

                if (found == false)
                {
                    Invalid f4 = new Invalid();
                    this.Hide();
                    f4.Show();
                }
                i = 0;
            }
        }
        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {    
            

        }

        private void button2_Click(object sender, EventArgs e)
        {
            SignUp f5 = new SignUp();
            
            f5.Show();
           
        }

        private void pictureBox5_Click(object sender, EventArgs e)
        {

        }

        private void SignIn_Load(object sender, EventArgs e)
        {

        }
    }
}

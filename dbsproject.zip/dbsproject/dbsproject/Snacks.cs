﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.Types;
using MySql.Data.MySqlClient;

namespace dbsproject
{
    public partial class Snacks : Form
    {
        TextBox total;
        Form3 f;
        int sum = 0;
        MySqlConnection conn;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        MySqlDataAdapter da;
        int i = 0;
        public Snacks(TextBox txt,Form3 frm)
        {
            f = frm;
            total = txt;
            InitializeComponent();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            i++;
            if (i >= dt.Rows.Count)
            {
                i = 0;
            }
               
            dr = dt.Rows[i];
            this.BackgroundImage = Image.FromFile(dr["photourl"].ToString());
            lblPrice.Text = "Price : " + dr["price"].ToString();
        }

        private void connect()
        {
            conn = new MySqlConnection("server = localhost; user id = root; password =9844897278jsn; database = users;");
            conn.Open();
        }

        private void Snacks_Load(object sender, EventArgs e)
        {
            connect();
            MySqlCommand comm = new MySqlCommand("select * from snacks", conn);
            comm.CommandType = CommandType.Text;
            da = new MySqlDataAdapter(comm.CommandText, conn);
            ds = new DataSet();
            da.Fill(ds, "snacks");
            dt = ds.Tables["snacks"];
            MessageBox.Show(dt.Rows.Count.ToString());
            dr = dt.Rows[i];
            this.BackgroundImage = Image.FromFile(dr["photourl"].ToString());
            lblPrice.Text = "Price : " + dr["price"].ToString();
            conn.Close();
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void txtqty_KeyDown(object sender, KeyEventArgs e)
        {
            if ((e.KeyCode >= Keys.A && e.KeyCode <= Keys.Z))
            {
                e.Handled = true;
                e.SuppressKeyPress = true;
            }
        }


        private void txtqty_KeyPress(object sender, KeyPressEventArgs e)
        {

            
            //MessageBox.Show(txtqty.Text);
            /*if (!isDecimal(e.KeyChar) )
            {
                if (txtqty.Text.Length > 1)
                {
                    txtqty.Text = txtqty.Text.ToString().Substring(0, txtqty.Text.Length - 1);
                }
                else
                {
                    txtqty.Text = "";
                }
            }*/
        }

        private void btnAdd_Click(object sender, EventArgs e)
        {
            int temp;
            
            
                temp = int.Parse(lblPrice.Text.Substring(lblPrice.Text.Length - 2));
            temp *= int.Parse(txtqty.Text);
            sum += temp;
                
           
                
               
            }

        private void btnDone_Click(object sender, EventArgs e)
        {
            sum += 120;
            total.Text = sum.ToString();
            f.Show();
            this.Hide();
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace dbsproject
{             // this form let's user choose a movie
    public partial class Book : Form
    {
        MySqlConnection conn;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        MySqlDataAdapter da;
        int i = 0;

        private void connect()
        {
            conn = new MySqlConnection("server = localhost; user id = root; password =9844897278jsn; database = users;");
            conn.Open();
        }

        public Book()
        {
            InitializeComponent();
        }

        private void Form2_Load(object sender, EventArgs e)
        {
            connect();
            MySqlCommand comm = new MySqlCommand("select * from movies", conn);
            comm.CommandType = CommandType.Text;
            da = new MySqlDataAdapter(comm.CommandText, conn);
            ds = new DataSet();
            da.Fill(ds, "movies");
            dt = ds.Tables["movies"];
            dr = dt.Rows[i];
            pictureBox1.Image = Image.FromFile(dr["photourl"].ToString());
            lblTitle.Text = dr["name1"].ToString();
            auditorium.Text = dr["auditorium"].ToString();
            timing.Text = dr["timing"].ToString();
            lblDate.Text = dr["date1"].ToString().Substring(0, 10);
            txtDesc.Text = dr["description"].ToString();
            conn.Close();
        }

        public  void button1_Click(object sender, EventArgs e)
        {
            Form3 f = new Form3(lblTitle.Text,auditorium.Text,timing.Text,lblDate.Text);
            f.Show();
            this.Hide();
        }

        private void button2_Click(object sender, EventArgs e)
        {
        }

        private void button3_Click(object sender, EventArgs e)
        { 
        }
         

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label3_Click_1(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void auditorium_Click(object sender, EventArgs e)
        {

        }

        private void button3_Click_1(object sender, EventArgs e)
        {
            i++;
            if (i >= dt.Rows.Count)
                i = 0;
            dr = dt.Rows[i];
            pictureBox1.Image = Image.FromFile(dr["photourl"].ToString());
            lblTitle.Text = dr["name1"].ToString();
            auditorium.Text = dr["auditorium"].ToString();
            timing.Text = dr["timing"].ToString();
            lblDate.Text = dr["date1"].ToString().Substring(0,10);
            txtDesc.Text = dr["description"].ToString();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            i--;
            if (i < 0)
                i = dt.Rows.Count - 1 ;
            dr = dt.Rows[i];
            pictureBox1.Image = Image.FromFile(dr["photourl"].ToString());
            lblTitle.Text = dr["name1"].ToString();
            auditorium.Text = dr["auditorium"].ToString();
            timing.Text = dr["timing"].ToString();
            lblDate.Text = dr["date1"].ToString().Substring(0, 10);
            txtDesc.Text = dr["description"].ToString();
        }

        private void txtDesc_TextChanged(object sender, EventArgs e)
        {

        }
    }
}

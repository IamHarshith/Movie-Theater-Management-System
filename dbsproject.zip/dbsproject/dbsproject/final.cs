﻿using MySql.Data.MySqlClient;
using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace dbsproject
{
    public partial class final : Form
    {

        MySqlConnection conn;
        DataSet ds,d;
        DataTable dt;
        DataRow dr;
        MySqlDataAdapter da,db;
        int i = 0;
        string firstsql = null;
        string secondsql=null;

        private void connect()
        {
            conn = new MySqlConnection("server = localhost; user id = root; password =9844897278jsn; database = users;");
            conn.Open();
        }

        public final()
        {
            InitializeComponent();
        }
        private void final_Load(object sender, EventArgs e)
        {
            
        }


        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label5_Click(object sender, EventArgs e)
        {

        }

       

        private void label4_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            connect();
            MySqlCommand comm = new MySqlCommand("select * from movies", conn);
            comm.CommandType = CommandType.Text;
            da = new MySqlDataAdapter(comm.CommandText, conn);
           // db = new MySqlDataAdapter(comm.CommandText, conn);
            ds = new DataSet();
            
            da.Fill(ds, "movies");
            dt = ds.Tables["movies"];
            //dt = ds.Tables["booked"];
            dr = dt.Rows[i];
            MySqlCommand con = new MySqlCommand("select * from booked", conn);
            con.CommandType = CommandType.Text;
           // da=new MySqlDataAdapter(comm.CommandTyp)
           // db.Fill(ds, "booked");

            //pictureBox1.Image = Image.FromFile(dr["photourl"].ToString());
            movie.Text = dr["name1"].ToString();
            audi.Text = dr["auditorium"].ToString();
            timee.Text = dr["timing"].ToString();
            datee.Text = dr["date1"].ToString().Substring(0, 10);
            Seatno.Text = dr["seat"].ToString();
            //cost.Text=dr[]
            



            //txtDesc.Text = dr["description"].ToString();
            conn.Close();

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }
    }
}

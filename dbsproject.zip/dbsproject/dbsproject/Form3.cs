﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;
using MySql.Data.MySqlClient;
using MySql.Data.Types;

namespace dbsproject
{  
    public partial class Form3 : Form
    {// int b_no;
        String seatno = "0";
        String mtitle;
        String maudi;
        String mtime;
        String mdate;
        string myConnectionString;
        MySql.Data.MySqlClient.MySqlConnection conn;
        MySql.Data.MySqlClient.MySqlDataAdapter adap;
        MySql.Data.MySqlClient.MySqlCommand cmd;
        DataSet ds;
        DataTable dt;
        DataRow dr;
        int cost=0;
        int totalSeatsBooked=0;
        String Audi;
       
        Button[,] btnSeat = new Button[21, 7];
        Label[] label = new Label[7];
        int[,] seatStatus = new int[21,7];

        

        public Form3(String title,string audi,string tim,string dim)
        {
            mtitle = title;
            maudi = audi;
            mtime = tim;
            mdate = dim;
            InitializeComponent();
        }

        public Form3()
        {
            InitializeComponent();
        }

        private void Form3_Load(object sender, EventArgs e)
        {

        }
        
          private void drawPlan()
        {
            int offset;

            int seatMax;
            for (int j = 1; j <= 6; j++)
            {
                seatMax = 20;
                if (j == 1) seatMax = 12;
                if (j == 2) seatMax = 14;
                if (j == 3) seatMax = 16;
                if (j == 4) seatMax = 17;
                //if (j >= 7 && j <= 9) seatMax = 19;
                //if (j == 11) seatMax = 20;
                for (int i = 1; i <= seatMax; i++)
                {
                    offset = 0;
                    if (j == 1) offset = 4;
                    if (j == 2) offset = 3;
                    if (j == 3) offset = 2;
                    if (j == 4) offset = 1;
                  //  if (j >= 7 && j <= 9) offset = 1;

                    btnSeat[i, j] = new Button();
                    btnSeat[i, j].Width = 20;
                    btnSeat[i, j].Height = 20;
                    btnSeat[i, j].Left = ((20 * i) + (20 * offset));
                    if ((i + offset) > 15)
                        btnSeat[i, j].Left += 20;
                    btnSeat[i, j].Top = (20 * j);
                    if(seatStatus[i , j] == 0)
                    btnSeat[i, j].Image = Image.FromFile("../../seat1.png");
                    if (seatStatus[i, j] == 1)
                        btnSeat[i, j].Image = Image.FromFile("../../Seat3.png");
                    String buttonName = "btn";
                    if (j <= 9)
                        buttonName += " ";
                    buttonName += j;
                    if (i <= 9)
                        buttonName += " ";
                    buttonName += i;
                    btnSeat[i, j].Name = buttonName;
                    btnSeat[i, j].Click += new EventHandler(seat_Click);

                     panel1.Controls.Add(btnSeat[i, j]);
                     int rowNumber = j;
                    // if (j > 8)
                      //   rowNumber++;
                     string tooltipText = Convert.ToChar(rowNumber + 64).ToString()
                     + (i).ToString();
                     ToolTip buttonToolTip = new ToolTip();
                     buttonToolTip.SetToolTip(btnSeat[i, j], tooltipText);

                }
                label[j] = new Label();
                label[j].Size = new System.Drawing.Size(14,10);
                char c = Convert.ToChar(64 + j);
                //if (j > 8)
                  //  c = Convert.ToChar(65 + j);
                label[j].Text = Convert.ToString(c);
                label[j].Font = new System.Drawing.Font("Microsoft Sans Serif",
                6F, System.Drawing.FontStyle.Regular,
               System.Drawing.GraphicsUnit.Point, ((byte)(0)));
                label[j].Location = new System.Drawing.Point(325, 4 + 20 * j);
                panel1.Controls.Add(label[j]);

            }
       

        }
          private void seat_Click(object sender, EventArgs e)
          {   
              
        }

        private void comboBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            
            
            
        }

        private void panel1_Paint(object sender, PaintEventArgs e)
        {

        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
        }

        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MySqlConnection conn = new MySqlConnection("server = localhost; user id = root; password =9844897278jsn; database = users;");
            conn.Open();

            MySqlCommand comm = new MySqlCommand("new_procedure", conn);
            comm.CommandType = CommandType.StoredProcedure;

            //MySqlParameter t = new MySqlParameter();
            comm.Parameters.AddWithValue("?t",mtitle);

            //MySqlParameter a = new MySqlParameter();
            //a.Value = maudi;
            //a.Direction = ParameterDirection.Input;
            //a.DbType = DbType.String;
            comm.Parameters.AddWithValue("?a",maudi);


            //MySqlParameter ti = new MySqlParameter();
            //ti.Value = mtime;
            //ti.Direction = ParameterDirection.Input;
            //ti.DbType = DbType.Time;
            comm.Parameters.AddWithValue("?ti",mtime);

            //MySqlParameter dd = new MySqlParameter();
            //dd.Value = mdate;
            //dd.Direction = ParameterDirection.Input;
            //dd.DbType = DbType.Date;
            comm.Parameters.AddWithValue("?dd",mdate);
            comm.Parameters.AddWithValue("?s",int.Parse(seatno));

            comm.Parameters["?t"].Direction = ParameterDirection.Input;
            comm.Parameters["?a"].Direction = ParameterDirection.Input;
            comm.Parameters["?ti"].Direction = ParameterDirection.Input;
            comm.Parameters["?dd"].Direction = ParameterDirection.Input;
            comm.Parameters["?s"].Direction = ParameterDirection.Input;
            comm.Parameters.Add(new MySqlParameter("?result", MySqlDbType.Int32));
            comm.Parameters["?result"].Direction = ParameterDirection.Output;
            if(label1.Text=="")
            {
                MessageBox.Show("Please select a seat");
            }

            try
            {

                comm.ExecuteNonQuery();
                if (comm.Parameters["?result"].Value.ToString().Equals("0")){
                    MySqlCommand cmd = new MySqlCommand();
                    cmd.Connection = conn;
                    cmd.CommandText = "insert into booked values('" + mtitle + "', '"+ maudi+ "', '"+ mtime + "', '" + mdate +"', '" + label1.Text + "')";
                    cmd.CommandType = CommandType.Text;

                    cmd.ExecuteNonQuery();
                    MessageBox.Show("Seat booked successfully!");
                    this.Hide();
                    link ll = new link();
                        ll.Show();
                   

                }
                else{
                    MessageBox.Show("Sorry,already booked!!");
                   
                }
            }catch(MySqlException ex){
                MessageBox.Show(ex.ToString());
            }
            

            

        }

        private void button3_Click(object sender, EventArgs e)
        {
            this.Hide();
        }

        private void btnSnack_Click(object sender, EventArgs e)
        {
            Snacks s = new Snacks(textBox1,this);
            s.Show();
            this.Hide();
        }

        private void label14_Click(object sender, EventArgs e)
        {

        }

        private void seat1_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label6_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label7_Click(object sender, EventArgs e)
        {
           // seatno = ((Label)sender).Text;
        }

        private void label8_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label7_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label32_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label31_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label30_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label29_Click(object sender, EventArgs e)
        {

        }

        private void label29_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label46_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label45_Click(object sender, EventArgs e)
        {

        }

        private void label45_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label44_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label43_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label60_MouseClick(object sender, MouseEventArgs e)
        {
           
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label59_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label58_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label57_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label10_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label11_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label12_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label13_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label27_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label26_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label25_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label24_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label41_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label40_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }


        private void label39_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label38_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label55_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label54_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label53_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label52_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label17_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label15_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label14_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label18_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label20_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label22_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label23_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label19_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label34_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label36_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label37_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label33_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label48_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label50_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label51_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label47_MouseClick(object sender, MouseEventArgs e)
        {
            seatno = ((Label)sender).Text;
            label1.Text = seatno;
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }
    }
}


 